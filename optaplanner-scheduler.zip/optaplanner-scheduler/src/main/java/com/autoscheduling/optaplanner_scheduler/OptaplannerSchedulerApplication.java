package com.autoscheduling.optaplanner_scheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OptaplannerSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OptaplannerSchedulerApplication.class, args);
	}

}
