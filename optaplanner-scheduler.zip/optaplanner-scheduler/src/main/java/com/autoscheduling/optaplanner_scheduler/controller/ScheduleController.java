package com.autoscheduling.optaplanner_scheduler.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.autoscheduling.optaplanner_scheduler.domain.Schedule;
import com.autoscheduling.optaplanner_scheduler.domain.SchedulingSolution;
import com.autoscheduling.optaplanner_scheduler.domain.WorkOrder;
import com.autoscheduling.optaplanner_scheduler.repository.ScheduleRepository;
import com.autoscheduling.optaplanner_scheduler.repository.WorkOrderRepository;
import com.autoscheduling.optaplanner_scheduler.service.OptaPlannerService;

@Controller
public class ScheduleController {

    @Autowired
    private ScheduleRepository scheduleRepository;

    @Autowired
    private WorkOrderRepository workOrderRepository;

    @Autowired
    private OptaPlannerService optaPlannerService;

    // 显示排班页面
    @GetMapping("/schedule")
    public String getSchedulePage(Model model) {
        List<Schedule> schedules = scheduleRepository.findAll(); // 从数据库获取所有排班记录
        model.addAttribute("schedules", schedules); // 将数据传递给前端页面
        return "schedule"; // 返回HTML页面
    }

    // 处理排班优化请求
    @PostMapping("/run-scheduler")
    public String runScheduler() {
        // 从数据库获取所有的 WorkOrder 数据
        List<WorkOrder> workOrderList = workOrderRepository.findAll();

         // 打印输入数据 - debug 
        workOrderList.forEach(workOrder -> System.out.println("Input WorkOrder: " + workOrder));

        // 创建一个空的 Schedule 列表
        List<Schedule> scheduleList = new ArrayList<>();

        // 构建 SchedulingSolution 对象
        SchedulingSolution schedulingSolution = new SchedulingSolution();
        schedulingSolution.setWorkOrders(workOrderList);
        schedulingSolution.setSchedules(scheduleList);

        // 调用 OptaPlannerService 进行排班优化
        SchedulingSolution optimizedSolution = optaPlannerService.optimizeSchedule(schedulingSolution);

        // 打印输出数据
        scheduleList.forEach(schedule -> System.out.println("Output Schedule: " + schedule));

        // 保存优化后的排班记录到数据库
        scheduleRepository.saveAll(optimizedSolution.getSchedules());

        // 重定向回排班页面
        return "redirect:/schedule";
    }
}
