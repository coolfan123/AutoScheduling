package com.autoscheduling.optaplanner_scheduler.domain;

import java.time.LocalDateTime;

import org.optaplanner.core.api.domain.entity.PlanningEntity;
import org.optaplanner.core.api.domain.variable.PlanningVariable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@PlanningEntity
@Table(name = "schedule") // 显式指定数据库表名为小写的 schedule
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @PlanningVariable(valueRangeProviderRefs = "startTimeRange", nullable = false)
    private LocalDateTime startTime; 
    private LocalDateTime endTime; 

    private WorkOrder workorder;  // 每个 Schedule 对应一个 workorder

    // 新增技工、工具、材料等字段
    @PlanningVariable(valueRangeProviderRefs = "technicianRange", nullable = true)
    private Technician assignedTechnician;

    @PlanningVariable(valueRangeProviderRefs = "toolRange", nullable = true)
    private Tool assignedTool;

    @PlanningVariable(valueRangeProviderRefs = "materialRange", nullable = true)
    private Material assignedMaterial;

    public Schedule() {
    }

    // WorkOrder 和 Schedule 的一对一关系构造函数
    public Schedule(WorkOrder workorder) {
        this.workorder = workorder;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public WorkOrder getWorkOrder() {
        return workorder;
    }

    public void setWorkOrder(WorkOrder workorder) {
        this.workorder = workorder;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Technician getAssignedTechnician() {
        return assignedTechnician;
    }

    public void setAssignedTechnician(Technician assignedTechnician) {
        this.assignedTechnician = assignedTechnician;
    }

    public Tool getAssignedTool() {
        return assignedTool;
    }

    public void setAssignedTool(Tool assignedTool) {
        this.assignedTool = assignedTool;
    }

    public Material getAssignedMaterial() {
        return assignedMaterial;
    }

    public void setAssignedMaterial(Material assignedMaterial) {
        this.assignedMaterial = assignedMaterial;
    }
}
