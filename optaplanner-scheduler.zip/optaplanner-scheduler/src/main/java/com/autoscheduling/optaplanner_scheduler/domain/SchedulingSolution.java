package com.autoscheduling.optaplanner_scheduler.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.optaplanner.core.api.domain.solution.PlanningEntityCollectionProperty;
import org.optaplanner.core.api.domain.solution.PlanningScore;
import org.optaplanner.core.api.domain.solution.PlanningSolution;
import org.optaplanner.core.api.domain.solution.ProblemFactCollectionProperty;
import org.optaplanner.core.api.domain.valuerange.ValueRangeProvider;
import org.optaplanner.core.api.score.buildin.hardsoftlong.HardSoftLongScore;

@PlanningSolution
public class SchedulingSolution {

    @ProblemFactCollectionProperty
    private List<WorkOrder> workOrders;  // 输入：未优化的 WorkOrder 数据

    @PlanningEntityCollectionProperty
    private List<Schedule> schedules = new ArrayList<>();     // 输出：优化后的 Schedule 数据
    
    // 使用 @PlanningScore 注解来标识得分属性
    @PlanningScore
    private HardSoftLongScore score;

    @ValueRangeProvider(id = "startTimeRange")
    public List<LocalDateTime> getStartTimeRange() {
        // 假设默认从今天开始，可以根据需求动态调整
        LocalDateTime today = LocalDateTime.now();
        return List.of(today, today.plusHours(1), today.plusHours(2)); // 这里可以返回更多时间点
    }

    @ValueRangeProvider(id = "technicianRange")
    private List<Technician> technicianRange = new ArrayList<>(); 

    @ValueRangeProvider(id = "toolRange")
    private List<Tool> toolRange = new ArrayList<>(); 

    @ValueRangeProvider(id = "materialRange")
    private List<Material> materialRange = new ArrayList<>(); 

    // 无参构造函数
    public SchedulingSolution() {
    }

    // 带参数的构造函数
    public SchedulingSolution(List<WorkOrder> workOrders, List<Schedule> schedules) {
        this.workOrders = workOrders;
        this.schedules = schedules;
    }

    // Getter and Setter for workOrders
    public List<WorkOrder> getWorkOrders() {
        return workOrders;
    }

    public void setWorkOrders(List<WorkOrder> workOrders) {
        this.workOrders = workOrders;
    }

    // Getter and Setter for schedules
    public List<Schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(List<Schedule> schedules) {
        this.schedules = schedules;
    }

    public List<Technician> getTechnicianRange() {
        return technicianRange;
    }

    public void setTechnicianRange(List<Technician> technicianRange) {
        this.technicianRange = technicianRange;
    }

    public List<Tool> getToolRange() {
        return toolRange;
    }

    public void setToolRange(List<Tool> toolRange) {
        this.toolRange = toolRange;
    }

    public List<Material> getMaterialRange() {
        return materialRange;
    }

    public void setMaterialRange(List<Material> materialRange) {
        this.materialRange = materialRange;
    }

    // Getter and Setter for score
    public HardSoftLongScore getScore() {
        return score;
    }

    public void setScore(HardSoftLongScore score) {
        this.score = score;
    }

}
