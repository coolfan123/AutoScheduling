package com.autoscheduling.optaplanner_scheduler.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity

@Table(name = "workorder") // 显式指定数据库表名为小写的 workorder
public class WorkOrder{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "duration") // 假设数据库字段为 duration
    private int duration; // 假设有一个开始时间字段

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getDuration() {
        return duration;
    }

    public void setDurtion(int duration) {
        this.duration = duration;
    }

}