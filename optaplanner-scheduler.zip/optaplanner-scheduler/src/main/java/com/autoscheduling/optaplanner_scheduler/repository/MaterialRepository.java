package com.autoscheduling.optaplanner_scheduler.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autoscheduling.optaplanner_scheduler.domain.Material;

public interface MaterialRepository extends JpaRepository<Material, Long> {
}
