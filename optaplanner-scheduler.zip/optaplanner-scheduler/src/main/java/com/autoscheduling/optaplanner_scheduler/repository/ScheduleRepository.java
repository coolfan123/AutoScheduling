package com.autoscheduling.optaplanner_scheduler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.autoscheduling.optaplanner_scheduler.domain.Schedule;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
    // 你可以添加自定义查询方法，这里仅作为示例
}