package com.autoscheduling.optaplanner_scheduler.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autoscheduling.optaplanner_scheduler.domain.Tool;

public interface ToolRepository extends JpaRepository<Tool, Long> {
}
