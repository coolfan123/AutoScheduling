package com.autoscheduling.optaplanner_scheduler.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;
import org.springframework.stereotype.Service;

import com.autoscheduling.optaplanner_scheduler.domain.Material;
import com.autoscheduling.optaplanner_scheduler.domain.Schedule;
import com.autoscheduling.optaplanner_scheduler.domain.SchedulingSolution;
import com.autoscheduling.optaplanner_scheduler.domain.Technician;
import com.autoscheduling.optaplanner_scheduler.domain.Tool;
import com.autoscheduling.optaplanner_scheduler.domain.WorkOrder;
import com.autoscheduling.optaplanner_scheduler.repository.MaterialRepository;
import com.autoscheduling.optaplanner_scheduler.repository.ScheduleRepository;
import com.autoscheduling.optaplanner_scheduler.repository.TechnicianRepository;
import com.autoscheduling.optaplanner_scheduler.repository.ToolRepository;
import com.autoscheduling.optaplanner_scheduler.repository.WorkOrderRepository;


@Service
public class OptaPlannerService {

    private final ScheduleRepository scheduleRepository;
    private final WorkOrderRepository workOrderRepository;
    private final TechnicianRepository technicianRepository;
    private final ToolRepository toolRepository;
    private final MaterialRepository materialRepository;

    public OptaPlannerService(ScheduleRepository scheduleRepository, WorkOrderRepository workOrderRepository, 
        TechnicianRepository technicianRepository, ToolRepository toolRepository, MaterialRepository materialRepository) {
        this.scheduleRepository = scheduleRepository;
        this.workOrderRepository = workOrderRepository;
        this.technicianRepository = technicianRepository;
        this.toolRepository = toolRepository;
        this.materialRepository = materialRepository;
    }

    // 处理优化排班的核心逻辑
    public SchedulingSolution optimizeSchedule(SchedulingSolution schedulingSolution) {
        // Step 1: Retrieve all WorkOrders from the database.
        List<WorkOrder> workOrders = workOrderRepository.findAll();

        // Step 2: Initialize a list of Schedules (empty schedules associated with WorkOrders).
        List<Schedule> schedules = new ArrayList<>();
        for (WorkOrder workOrder : workOrders) {
            schedules.add(new Schedule(workOrder));
        }

        // Step 3: Set the workOrders and schedules in the existing schedulingSolution object.
        schedulingSolution.setWorkOrders(workOrders);
        schedulingSolution.setSchedules(schedules);

        // debug
        // System.out.println("Scheduling Solution contains the following WorkOrders:");
        // for (WorkOrder workOrder : schedulingSolution.getWorkOrders()) {
        //     System.out.println("WorkOrder ID: " + workOrder.getId() + ", Duration: " + workOrder.getDuration());
        // }

        // 使用 OptaPlanner 进行排班优化
        SolverFactory<SchedulingSolution> solverFactory = SolverFactory.createFromXmlResource("solverConfig.xml");       
        Solver<SchedulingSolution> solver = solverFactory.buildSolver();
        
        // 调用 OptaPlanner 进行优化
        SchedulingSolution optimizedSolution = solver.solve(schedulingSolution);

        // 输出优化后的得分
        System.out.println("Optimized solution score: " + optimizedSolution.getScore());

        LocalDateTime currentTime = LocalDateTime.now();
        for (Schedule schedule : optimizedSolution.getSchedules()) {
            if (schedule.getStartTime() == null) {
                schedule.setStartTime(currentTime); // 设置为当前时间（仅作为示例）
            }
            // 计算 end time
            if (schedule.getEndTime() == null) {
                LocalDateTime endTime = schedule.getStartTime().plusMinutes(schedule.getWorkOrder().getDuration()); // 计算 end time
                schedule.setEndTime(endTime);
            }

            // 为下一个任务设置开始时间
            currentTime = schedule.getEndTime();  // 下一个任务的 start time 就是当前任务的 end time
        }

        // 保存优化后的 Schedule 数据到数据库
        saveOptimizedSchedule(optimizedSolution.getSchedules());
        return optimizedSolution;
    }

    // 将优化后的 Schedule 存入数据库
    private void saveOptimizedSchedule(List<Schedule> optimizedSchedules) {

        optimizedSchedules.sort(Comparator.comparingLong(schedule -> schedule.getWorkOrder().getDuration()));

        scheduleRepository.saveAll(optimizedSchedules);
    }

    // 获取所有工作订单
    public List<WorkOrder> getAllWorkOrders() {
        return workOrderRepository.findAll();
    }

    // 获取所有排班
    public List<Schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }

    public List<Technician> getTechnicianList() {
        return technicianRepository.findAll();
    }

    public List<Tool> getToolList() {
        return toolRepository.findAll();
    }

    public List<Material> getMaterialList() {
        return materialRepository.findAll();
    }
    
}
