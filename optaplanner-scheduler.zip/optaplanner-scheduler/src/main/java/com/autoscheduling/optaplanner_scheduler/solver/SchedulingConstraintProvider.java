package com.autoscheduling.optaplanner_scheduler.solver;

import org.optaplanner.core.api.score.buildin.hardsoftlong.HardSoftLongScore;
import org.optaplanner.core.api.score.stream.Constraint;
import org.optaplanner.core.api.score.stream.ConstraintFactory;
import org.optaplanner.core.api.score.stream.ConstraintProvider;

import com.autoscheduling.optaplanner_scheduler.domain.WorkOrder;

public class SchedulingConstraintProvider implements ConstraintProvider {

    @Override
    public Constraint[] defineConstraints(ConstraintFactory constraintFactory) {
        return new Constraint[]{
            durationConstraint(constraintFactory)
        };
    }

    private Constraint durationConstraint(ConstraintFactory constraintFactory) {
        return constraintFactory.forEach(WorkOrder.class)
            .penalize(
                HardSoftLongScore.ONE_SOFT,
                WorkOrder::getDuration)
            .asConstraint("Duration Constraint");
    }
}
